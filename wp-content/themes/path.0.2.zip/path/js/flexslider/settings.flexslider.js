// Flexslider
jQuery(window).load(function() {
    jQuery('.flexslider').flexslider({
		slideshow: true
	});
});