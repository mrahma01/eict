// Basic FitVids
jQuery(document).ready(function() {
    		jQuery('#content').fitVids();
    	});